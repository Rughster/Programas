package editorialA;
import java.util.ArrayList;
import java.util.Iterator;
import jerarquiaHerencia.*;
public class ManPublica {
    static ArrayList<Publicaciones> ArrPublica = new ArrayList<Publicaciones>();
    private Libro objLibro;
    private Revista objRevista;
    private Periodico objPeriodico;
    private Publicaciones objPublica;
    
    public ManPublica(){}
    
    public ManPublica(String tit, double precio, int np){
        objPublica = new Publicaciones();
        objPublica.setTitulo(tit);
        objPublica.setPrecio(precio);
        objPublica.setNoPag(np);
    }
    
    public void alta(String ISBN, String Autor, String edicion){    //ALTA Libro
        objLibro = new Libro();
        objLibro.setTitulo(objPublica.getTitulo());
        objLibro.setPrecio(objPublica.getPrecio());
        objLibro.setNoPag(objPublica.getNoPag());
        objLibro.setISBN(ISBN);
        objLibro.setAutor(Autor);
        objLibro.setEdicion(edicion);
        ArrPublica.add(objLibro);
    }
    
    public void altaR(String ISSN, String num){                     //ALTA Revista
        objRevista = new Revista();
        objRevista.setTitulo(objPublica.getTitulo());
        objRevista.setPrecio(objPublica.getPrecio());
        objRevista.setNoPag(objPublica.getNoPag());
        objRevista.setISSN(ISSN);
        objRevista.setNumero(Integer.parseInt(num));
        ArrPublica.add(objRevista);
    }
    
    public void altaP(String editor){                               //ALTA Periodico    
        objPeriodico = new Periodico();
        objPeriodico.setTitulo(objPublica.getTitulo());
        objPeriodico.setPrecio(objPublica.getPrecio());
        objPeriodico.setNoPag(objPublica.getNoPag());
        objPeriodico.setEditor(editor);
        ArrPublica.add(objPeriodico);
        
    }    
    public void desplegar(){
        System.out.println("....OBJETOS EN LA PUBLICACIÓN....");
        Iterator<Publicaciones> itrPublica = ArrPublica.iterator();//Iterator
        while(itrPublica.hasNext()){
            Publicaciones publica = itrPublica.next();
            if(publica instanceof Libro){
                Libro book = new Libro();
                book = (Libro)publica;
                System.out.println("---LIBRO---\nTítulo: " + book.getTitulo()
                    + "\nPrecio: " + book.getPrecio()
                    + "\nNúmero de Páginas: " + book.getNoPag());
                System.out.println("ISBN: " + book.getISBN());
                System.out.println("Título: " + book.getTitulo());
            }
            else if(publica instanceof Revista){
                Revista revi = new Revista();
                revi = (Revista)publica;
                System.out.println("---REVISTA---\nTítulo: " + revi.getTitulo()
                    + "\nPrecio: " + revi.getPrecio()
                    + "\nNúmero de Páginas: " + revi.getNoPag());
                System.out.println("ISSB: " + revi.getISSN());
                System.out.println("Número: " + revi.getNumero());
            }
            else if(publica instanceof Periodico){
                Periodico peri = new Periodico();
                peri = (Periodico)publica;
                System.out.println("---PERIODICO---\nTítulo: " + peri.getTitulo()
                    + "\nPrecio: " + peri.getPrecio()
                    + "\nNúmero de Páginas: " + peri.getNoPag());
                System.out.println("Editor: " + peri.getEditor());
            }
        }
    }
    
    public ArrayList Datos(){
        return ArrPublica;
    }
}
