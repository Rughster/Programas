package editorialA;

import vista.Bienvenida;

public class EditorialA {
    public static void main(String[] args){
        Bienvenida bi = new Bienvenida();
        bi.setVisible(true);
        
    }
}
